//
//  protopypes.c
//  classmnt
//
//  Created by Mareme Diop on 05/07/2021.
//

#include "protopypes.h"
void saisi_tab(int tab[] ,int n)
{
    int i;
    for (i=0;i<n;i++)
    {
        printf ("\n saisir tab[%d] :",i+1);
        scanf("%d",&tab[i]);
    }
}
