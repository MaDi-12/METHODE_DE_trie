//
//  main.c
//  classmnt
//
//  Created by Mareme Diop on 05/07/2021.
//

#include <stdio.h>
#include "protopypes.h"


int main(int argc, const char * argv[])
{
    const int n=5;
    int tab[n],tab1[n],i,D,x,j,A;
    saisi_tab(tab,n);

    for (i=0; i<n; i++)
    {
        A=tab[i];
        for (D=i+1; D<n; D++)
        {
            if (A>=tab[D])
            {A=tab[D];
                x=D;}
        }
        tab1[i]=A;
        j=tab[i];
        tab[i]=tab[x];
        tab[x]=j;
        
        
    }
    printf("\n affichachage des variables du tableau de %d elements",n);
    for (i=0;i<n;i++)
    {
        printf ("\n  tab[%d]= %d '\n",i+1,tab1[i]);
    }
    return 0;
}
