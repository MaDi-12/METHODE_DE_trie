//
//  protopypes.h
//  classmnt
//
//  Created by Mareme Diop on 05/07/2021.
//

#ifndef protopypes_h
#define protopypes_h

#include <stdio.h>

#endif /* protopypes_h */
void saisi_tab(int tab[] ,int n);
